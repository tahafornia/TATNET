TR:
Türkçe QWERTY olan Windows bilgisayarlar için Kiril (Tatarca karakterlerde mevcut) karakterlerini Bilgisayarlarınıza yükleyebilirsiniz böylece Türkçe Q olan tuş takımınızda karşılığı olan Kiril karakterler entegre edilmiş olacak. Kısacası herhangi Türkçe Latin karaktere bastığınızda Kiril karşılığını verir.

Nasıl yüklenir?
İndirilen zip dosyasını açın, "setup" yazan dosyaya basıp yükleyebilirsiniz.
Daha sonrasında da Görev Çubuğunda Dil kodlarının kısaltmaları gözükecektir.
Klavye değiştirmek için Sistem varsayılanı Kısayol tuşlarını kullanabilir yada Görev Çubuğundaki Dil kısaltması yazan yere basarak değişim yapabilirsiniz. 


EN:
For Windows computers with Turkish QWERTY, you can install Cyrillic (Tatar characters are also available) characters on your computers, so that the corresponding Cyrillic characters will be integrated on your Turkish Q keypad. In short, when you press any Turkish-Latin character, it gives its Cyrillic equivalent.

How to install?
Open the downloaded zip file, click on the file that says "setup" and install it.
Afterwards, the abbreviations of the language codes will appear in the Task Bar.
To change the keyboard, you can use the System default Shortcut keys or change it by pressing the Language abbreviation on the Taskbar.


RU:
На компьютерах Windows с турецкой QWERTY вы можете установить на свои компьютеры символы кириллицы (также доступны татарские символы), чтобы соответствующие символы кириллицы были интегрированы в вашу турецкую Q клавиатуру. Короче говоря, когда вы нажимаете любой турецко-латинский символ, он дает его кириллический эквивалент.

Как установить?
Откройте загруженный zip-файл, щелкните файл с надписью «setup» и установите его.
После этого в панели задач появятся сокращения кодов языков.
Чтобы сменить клавиатуру, вы можете использовать сочетания клавиш по умолчанию или изменить их, щелкнув сокращение «Язык» на панели задач.


TAT:
Төрек QWERTY булган Windows компьютерлар өчен кирилл символларын(татар символлары да бар) үз компьютерларыгызга урнаштыра аласыз, шуңа күрә кирилл символлары сезнең төрек Q клавиатурасына интеграцияләнсен. Кыскасы, теләсә нинди төрек-латин символын басканда, аның кирилл эквивалентын бирә.

Ничек урнаштырырга?
Йөкләнгән zip файлыны ачыгыз, "setup" дигән файлга басып, урнаштырыгыз.
Аннан соң да, Тапшыру Тактасында тел кодларының кыскартулары барлыкка киләчәк.
Клавиатураны үзгәртү өчен, системаның кыска төймәләрен кулланып яки Тапшыру Тактасындагы Тел кыскартуын басып үзгәртә аласыз.